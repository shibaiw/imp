# public
portainer-ce 汉化文件

X86 CPU一键安装
```
sh -c "$(curl -kfsSl https://gitee.com/expin/public/raw/master/onex86.sh)"
```

N1等ARM64架构CPU一键安装
```
sh -c "$(curl -kfsSl https://gitee.com/expin/public/raw/master/one.sh)"
```
